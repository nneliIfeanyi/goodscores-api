ALTER TABLE questions
    ADD COLUMN content_type VARCHAR(40) NOT NULL DEFAULT 'standard' AFTER diagram_request;