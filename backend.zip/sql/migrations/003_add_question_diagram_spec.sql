ALTER TABLE questions
    ADD COLUMN diagram_spec JSON NULL AFTER diagram_request;

ALTER TABLE question_images
    MODIFY COLUMN type ENUM('diagram', 'label', 'option_image', 'general', 'ai_illustration') NOT NULL DEFAULT 'diagram';